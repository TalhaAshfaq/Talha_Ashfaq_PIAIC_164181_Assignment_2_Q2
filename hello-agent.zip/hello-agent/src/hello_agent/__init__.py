def main() -> None:
    print("Hello from hello-agent!")
